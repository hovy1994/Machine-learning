from __future__ import print_function
import grpc
from google.protobuf import json_format
import file_pb2
import file_pb2_grpc
from threading import Thread
import json
from collections.abc import Iterator
import itertools
from json.encoder import JSONEncoder
import ast
from multiprocessing import Queue
import time

from skgarden import MondrianForestRegressor
import numpy as np
import pandas as pd

import rrcf

try:
    import queue
except ImportError:
    import Queue as queue


class Client:
    """ gRPC Client class for streaming competition platform"""
    channel = None
    stub = None

    def __init__(self, batch_size):
        """

        :param batch_size: Integer value, defined by the competition and available at competition page
        :param server_port: Connection string ('IP:port')
        :param user_email: String, e-mail used for registering to competition
        :param token: String, received after subscription to a competition
        :param competition_code: String, received after subscription to a competition
        :param first_prediction: Prediction, class generated from .proto file. Used to initiate communication with the
        server. Not influencing the results. Should contain appropriate fields from .proto file.
        """

        self.batch_size = batch_size
        self.stop_thread = False
        self.predictions_to_send = Queue()
        self.channel = grpc.insecure_channel('app.streaming-challenge.com:50051')
        self.stub = file_pb2_grpc.DataStreamerStub(self.channel)
        self.user_email = 'hovy199431@gmail.com'
        self.competition_code = 'q2'
        self.token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJjb21wZXRpdGlvbl9pZCI6OCwidXNlcl9pZCI6ImhvdnkxOTk0MzFAZ21haWwuY29tIn0.cU8HifGQyxtGjR0Xgn0IcZCkKtNyfRpArYn2hON0XBM'
        self.predictions_to_send.put(file_pb2.Prediction(rowID=1000, target=333))
        self.metadata = self.create_metadata(user_id=self.user_email, code=self.competition_code, token=self.token)

        #mondrian
        self.mfr = MondrianForestRegressor(random_state=1, n_estimators=100, bootstrap=True)
        self.previous_target_5 = pd.Series(data=[-1.0, -1.0, -1.0, -1.0, -1.0], index=['prev1', 'prev2', 'prev3', 'prev4', 'prev5'])
        self.features_for_rowID = Queue()
        self.previous_train_batch = np.array([-1, -1, -1, -1, -1])
        #rrcf
        self.num_trees = 40
        self.tree_size = 256
        self.forest = self.create_forest(num_trees=self.num_trees)
        self.avg_codisp = {}
        self.curr_sum = 0
        self.curr_num = 0
        self.previous_sum_5=0 # add previous 5 values

    @staticmethod
    def create_metadata(user_id, code, token):
        """
        :param user_id:
        :param code:
        :param token:
        :return:
        """
        metadata = [(b'authorization', bytes(token, 'utf-8')), (b'user_id', bytes(user_id, 'utf-8')),
                    (b'competition_id', bytes(code, 'utf-8'))]
        return metadata

    @staticmethod
    def create_forest(num_trees):

        forest = []
        for _ in range(num_trees):
            tree = rrcf.RCTree()
            forest.append(tree)

        return forest


    def generate_predictions(self):
        """
        Sending predictions

        :return: Prediction
        """
        while True:
            try:
                prediction = self.predictions_to_send.get(block=True, timeout=60)
                print("Prediction: ", prediction)
                yield prediction
            except queue.Empty:
                self.stop_thread = True
                break

    
    # predict with previous 5 values' mean
    def predict_mean(self, previous_target_5):
        self.previous_sum_5 = previous_target_5['prev5']
        self.previous_sum_5 += previous_target_5['prev4']
        self.previous_sum_5 += previous_target_5['prev3']
        self.previous_sum_5 += previous_target_5['prev2']
        self.previous_sum_5 += previous_target_5['prev1']
        # add all the previous 5 values
        
        return previous_target_5 / 5 # and return the mean


    def loop_messages(self):
        """
        Getting messages (data instances) from the stream.

        :return:
        """

        #generate prediction -> get prediction from predictions_to_send one by one ans SEND to server

        messages = self.stub.sendData(self.generate_predictions(), metadata=self.metadata)
        test_idx = 0
        test_feature = self.previous_target_5

        try:
            for message in messages:

                message = json.loads(json_format.MessageToJson(message))
                print("message:", message)
                if message['tag'] == 'TEST':
                    
                    test_feature['prev5'] = test_feature['prev4']
                    test_feature['prev4'] = test_feature['prev3']
                    test_feature['prev3'] = test_feature['prev2']
                    test_feature['prev2'] = test_feature['prev1']
                    test_feature['prev1'] = self.previous_train_batch[test_idx]
                    
                    # calculate 5 previous values
                    pred = self.predict_mean(self.test_feature)
                    prediction = file_pb2_grpc.Prediction(rowID=message['rowID'], target=pred)
                    self.predictions_to_send.put(prediction)

                    test_idx += 1

                if message['tag'] == 'TRAIN':
                    #training data to train my model.

                    target = message['target']
                    target = self.anomaly_detection(target, message['rowID'])

                    self.curr_sum += target
                    self.curr_num += 1

                    # 이전 5개 값의 평균
                    if  self.previous_target_5['prev5'] < 0 :
                        self.previous_target_5['prev5'] = target
                    elif self.previous_target_5['prev4'] < 0 :
                        self.previous_target_5['prev4'] = target
                    elif self.previous_target_5['prev3'] < 0 :
                        self.previous_target_5['prev3'] = target
                    elif self.previous_target_5['prev2'] < 0 :
                        self.previous_target_5['prev2'] = target
                    elif self.previous_target_5['prev1'] < 0 :
                        self.previous_target_5['prev1'] = target
                    else :
                        #replace the oldest value
                        self.previous_target_5['prev5'] = self.previous_target_5['prev4'] #-9
                        self.previous_target_5['prev4'] = self.previous_target_5['prev3'] #-8
                        self.previous_target_5['prev3'] = self.previous_target_5['prev2'] #-7
                        self.previous_target_5['prev2'] = self.previous_target_5['prev1'] #-6
                        self.previous_target_5['prev1'] = self.previous_train_batch[0] #-5

                        #현재 train data의 target값 저장
                        np.roll(self.previous_train_batch, -1)
                        self.previous_train_batch[4] = target

                if self.stop_thread : break

        except Exception as e:
            print(str(e))
            pass

    def run(self):
        """
        Start thread.
        """
        print("Start")
        t1 = Thread(target=self.loop_messages)
        t1.start()


if __name__ == "__main__":
    client_1 = Client(batch_size=5)
    client_1.run()