
if __name__ == "__main__":
    arr1[11520]=1
    