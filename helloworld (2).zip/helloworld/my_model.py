import numpy as np
import pandas as pd

import rrcf   
    

def score_for_res(pred, trueval) :
    u2 = (pred-trueval)**2
    v2 = (trueval-trueval.mean())**2
    
    return 1-(u2.sum()/v2.sum())


def partial_train(mtr, X_test, y_test):
    y_pred, y_std = mtr.predict(X_test, return_std=True)
    mtr.partial_fit(X_test, y_test)
    #print('pred : %f, std: %f, y: %f'%(y_pred, y_std, y_test))
    return y_pred, y_std

def initial_training(self):
    network = pd.read_csv('initial_training_data.csv', index_col='date', parse_dates=['date'])
    network.head()

    rcParams['figure.figsize'] = 17,10
    network.describe()
    network.plot()

    network.describe()

    #construct forest of empty RCTrees

    #num_trees = 40
    shingle_size = 60
    #tree_size = 256


    self.forest = []
    for _ in range(self.num_trees):
        tree = rrcf.RCTree()
        forest.append(tree)


    #train data 정제
    ntw_clean = network.copy()

    train_len = 10000
    ntw_clean = ntw_clean[:train_len]

    #avg_codisp = {}
    train_mean = ntw_clean.mean()

    ntw_clean.plot()

    for index in range(0, train_len) :
        point = ntw_clean[index:index+1] #get one by one
    
    for tree in forest :
        if len(tree.leaves) > self.tree_size :
            tree.forget_point(index-self.tree_size)
            
        tree.insert_point(point, index=index)
        
        if not index in avg_codisp :
            avg_codisp[index] = 0
        avg_codisp[index] += tree.codisp(index) / self.num_trees
    #avg_codisp은 (각 tree 이 point를 anomaly로 생각하는 정도)의 평균
    mean = np.array(list(avg_codisp.values())).mean()
    std = np.array(list(avg_codisp.values())).std()
        
    z = (avg_codisp[index] - mean)/std
    if z > 3.0 or z < -3.0 :
        #if abs(z-score) is over 3.0
        #replace the value with the mean of training data
        
        ntw_clean.iloc[index] = train_mean
        
    
    #train set만들기
    tmp = ntw_clean.shift(1)
    tmp2 = ntw_clean.shift(2)
    tmp3 = ntw_clean.shift(3)

    ntw_prev = ntw_clean.copy()
    ntw_prev['prev1'] = tmp['target']
    ntw_prev['prev2'] = tmp2['target']
    ntw_prev['prev3'] = tmp3['target']

    ntw_prev = ntw_prev[4:]
    ntw_prev.tail()

    

    #training은 clean한 data로, test는 clean하지 않은 data를 rrcf로 다시 정제하면서 진행할거임
    #xt = [network[10000:10001], network.iloc[10001], network.iloc[10002]]
    xt = pd.Series()

    mfr = MondrianForestRegressor(random_state = 1, n_estimators=100, bootstrap=True)
    for i in range(3, len(ntw_clean)):
        X_train = pd.Series()
        X_train['prev1'] = ntw_clean[i-3:i-2]['target']
        X_train['prev2'] = ntw_clean[i-2:i-1]['target']
        X_train['prev3'] = ntw_clean[i-1:i]['target']
        y_train = ntw_clean[i:i+1]['target']
        mfr.partial_fit(X_train.values.reshape(1, -1), y_train)

    prediction = np.array([])
    stdeviation = np.array([])

    #일단 Test mean은 train mean과 같게 시작
    test_sum = ntw_clean.sum()
    test_num = ntw_clean.size
    yt = 0

    cleaned = np.array([])
    for i in range(0, 50000) :
        yp = yt
        if (i == 0) : 
            yp = None
        
        yt = network[10004+i:10004+i+1]['target']
        xt['prev1'] = network[10001+i:10001+i+1]['target']
        xt['prev2'] = network[10002+i:10002+i+1]['target']
        xt['prev3'] = network[10003+i:10003+i+1]['target']

        #train의 index가 9999에서 끝났으니까, 10000부터 시작
        index = i+10000
        #yt의 anomaly여부 판단
        for tree in forest :
            if len(tree.leaves) > self.tree_size :
                tree.forget_point(index-self.tree_size)
                
            tree.insert_point(yt, index=index)
            
            if not index in avg_codisp :
                avg_codisp[index] = 0
            avg_codisp[index] += tree.codisp(index) / self.num_trees
        #avg_codisp은 (각 tree 이 point를 anomaly로 생각하는 정도)의 평균
        mean = np.array(list(avg_codisp.values())).mean()
        std = np.array(list(avg_codisp.values())).std()
            
        z = (avg_codisp[index] - mean)/std
        if z > 3.0 or z < -3.0 :
            #if abs(z-score) is over 3.0
            #replace the value with the mean of training data
            print(index, z, yt)
            yt = test_sum/test_num
            print(index, z, yt)
        
    
        cleaned = np.append(cleaned, [yt])
        y_pred, y_std = partial_train(mfr, xt.values.reshape(1, -1), yt)
        #과거 3개만 저장
        np.roll(xt, -1)
        xt[2] = yt
        
        test_sum += yt.values
        test_num += 1
        
    
        prediction = np.append(prediction, [y_pred])
        stdeviation = np.append(stdeviation, [y_std])