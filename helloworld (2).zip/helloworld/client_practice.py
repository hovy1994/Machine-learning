# Copyright 2015 gRPC authors.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""The Python implementation of the GRPC helloworld.Greeter client."""
 
from __future__ import print_function
import logging
 
import grpc
import helloworld_pb2
import helloworld_pb2_grpc
 
import os
import warnings
warnings.filterwarnings('ignore')
from skgarden import MondrianForestRegressor
import numpy as np
import pandas as pd
from itertools import cycle
from sklearn.metrics import mean_squared_error
 
import time
from sklearn.metrics import r2_score
import rrcf
 
import csv
 
""" 
수정 전
def run():
    # NOTE(gRPC Python Team): .close() is possible on a channel and should be
    # used in circumstances in which the with statement does not fit the needs
    # of the code.
    
    with grpc.insecure_channel('localhost:50051') as channel:
        stub = helloworld_pb2_grpc.GreeterStub(channel)
        response = stub.SayHello(helloworld_pb2.HelloRequest(name='you'))
    print("Greeter client received: " + response.message)
"""
def score_for_res(pred, trueval) :
    u2 = (pred-trueval)**2
    v2 = (trueval-trueval.mean())**2
    
    return 1-(u2.sum()/v2.sum())
 
 
def partial_train(mtr, X_test, y_test):
    y_pred, y_std = mtr.predict(X_test, return_std=True)
    mtr.partial_fit(X_test, y_test)
    #print('pred : %f, std: %f, y: %f'%(y_pred, y_std, y_test))
    return y_pred, y_std
 
def run():
    start=time.time()
    network = pd.read_csv('initial_training_data.csv', index_col='date', parse_dates=['date'])
    network.head()
 
 
    #construct forest of empty RCTrees
 
    num_trees = 40
    shingle_size = 60
    tree_size = 256
 
 
    forest = []
    for _ in range(num_trees):
        tree = rrcf.RCTree()
        forest.append(tree)
 
 
    #train data 정제
    ntw_clean = network.copy()
 
 
    total_len=len(network)
    train_len = 1000
    ntw_clean = ntw_clean[train_len-1000:train_len]
 
 
    avg_codisp = {}
    train_mean = ntw_clean.mean()
 
   
    for index in range(0, 1000):
        point = ntw_clean[index:index+1] #get one by one
    
        for tree in forest :
            if len(tree.leaves) > tree_size :
                tree.forget_point(index-tree_size)
            
            tree.insert_point(point, index=index)
            
            if not index in avg_codisp :
                avg_codisp[index] = 0
            avg_codisp[index] += tree.codisp(index) / num_trees
        #avg_codisp은 (각 tree 이 point를 anomaly로 생각하는 정도)의 평균
        mean = np.array(list(avg_codisp.values())).mean()
        std = np.array(list(avg_codisp.values())).std()
            
        z = (avg_codisp[index] - mean)/std
        if z > 3.0 or z < -3.0 :
            #if abs(z-score) is over 3.0
            #replace the value with the mean of training data
            
            ntw_clean.iloc[index] = train_mean
            
    print("anomaly detection time: ",time.time()-start)
    f =open('avg_codisp.csv','w',encoding='utf-8')
    wr=csv.writer(f)
    wr.writerow(avg_codisp.values())
    
    #train set만들기
    tmp = ntw_clean.shift(1)
    tmp2 = ntw_clean.shift(2)
    tmp3 = ntw_clean.shift(3)
 
    ntw_prev = ntw_clean.copy()
    ntw_prev['prev1'] = tmp['target']
    ntw_prev['prev2'] = tmp2['target']
    ntw_prev['prev3'] = tmp3['target']
 
    ntw_prev = ntw_prev[4:]
    ntw_prev.tail()
 
    
 
    #training은 clean한 data로, test는 clean하지 않은 data를 rrcf로 다시 정제하면서 진행할거임
    #xt = [network[10000:10001], network.iloc[10001], network.iloc[10002]]
    xt = pd.Series()
 
    mfr = MondrianForestRegressor(random_state = 1, n_estimators=100, bootstrap=True)
    for i in range(3, len(ntw_clean)):
        X_train = pd.Series()
        X_train['prev1'] = ntw_clean[i-3:i-2]['target']
        X_train['prev2'] = ntw_clean[i-2:i-1]['target']
        X_train['prev3'] = ntw_clean[i-1:i]['target']
        y_train = ntw_clean[i:i+1]['target']
        mfr.partial_fit(X_train.values.reshape(1, -1), y_train)
 
    prediction = np.array([])
    stdeviation = np.array([])
 
    print("training time: ",time.time()-start)


    '''
    #일단 Test mean은 train mean과 같게 시작
    test_sum = ntw_clean.sum()
    test_num = ntw_clean.size
    yt = 0
 
    cleaned = np.array([])
    for i in range(0, 50000) :
        yp = yt
        if (i == 0) : 
            yp = None
        
        yt = network[1004+i:1004+i+1]['target']
        xt['prev1'] = network[1001+i:1001+i+1]['target']
        xt['prev2'] = network[1002+i:1002+i+1]['target']
        xt['prev3'] = network[1003+i:1003+i+1]['target']
 
        
        #train의 index가 9999에서 끝났으니까, 10000부터 시작
        index = i+1000
        #yt의 anomaly여부 판단
        for tree in forest :
            if len(tree.leaves) > tree_size :
                tree.forget_point(index-tree_size)
                 
            tree.insert_point(yt, index=index)
            
            if not index in avg_codisp :
                avg_codisp[index] = 0
            avg_codisp[index] += tree.codisp(index) / num_trees
        #avg_codisp은 (각 tree 이 point를 anomaly로 생각하는 정도)의 평균
        mean = np.array(list(avg_codisp.values())).mean()
        std = np.array(list(avg_codisp.values())).std()
        
        z = (avg_codisp[index] - mean)/std
        if z > 3.0 or z < -3.0 :
            #if abs(z-score) is over 3.0
            #replace the value with the mean of training data
            yt = test_sum/test_num
           
    
        cleaned = np.append(cleaned, [yt])
        y_pred, y_std = partial_train(mfr, xt.values.reshape(1, -1), yt)
        #과거 3개만 저장
        np.roll(xt, -1)
        xt[2] = yt
        
        test_sum += yt.values
        test_num += 1
        
    
        prediction = np.append(prediction, [y_pred])
        stdeviation = np.append(stdeviation, [y_std])
        
    print(mfr.score(prediction,yt))
    '''
 
 
 
    channel = grpc.insecure_channel('localhost:50051')
    stub = helloworld_pb2_grpc.GreeterStub(channel)
    response = stub.SayHello(helloworld_pb2.HelloRequest(name='you'))
    print("Greeter client received: " + response.message)
    response = stub.SayHelloAgain(helloworld_pb2.HelloRequest(name='you'))
    print("Greeter client received: " + response.message)
 
 
 
if __name__ == '__main__':
    logging.basicConfig()
    run()
 


