from __future__ import print_function
import grpc
from google.protobuf import json_format
import file_pb2
import file_pb2_grpc
from threading import Thread
import json
from collections.abc import Iterator
import itertools
from json.encoder import JSONEncoder
import ast
from multiprocessing import Queue
import time

from skgarden import MondrianForestRegressor
import numpy as np
import pandas as pd

import rrcf

try:
    import queue
except ImportError:
    import Queue as queue






class Client:
    """ gRPC Client class for streaming competition platform"""
    channel = None
    stub = None

    def __init__(self, batch_size):
        """

        :param batch_size: Integer value, defined by the competition and available at competition page
        :param server_port: Connection string ('IP:port')
        :param user_email: String, e-mail used for registering to competition
        :param token: String, received after subscription to a competition
        :param competition_code: String, received after subscription to a competition
        :param first_prediction: Prediction, class generated from .proto file. Used to initiate communication with the
        server. Not influencing the results. Should contain appropriate fields from .proto file.
        """
        self.mfr = MondrianForestRegressor(random_state=1, n_estimators=100, bootstrap=True)
        self.previous_target_3 = np.array([])
        self.num_trees = 40
        self.tree_size = 256
        self.forest = self.create_forest(num_trees=self.num_trees)
        self.avg_codisp = {}
        self.curr_sum = 0
        self.curr_num = 0

        self._init_modeling(self) # training 먼저 시키자

        self.batch_size = batch_size
        self.stop_thread = False
        self.predictions_to_send = Queue()
        self.channel = grpc.insecure_channel('app.streaming-challenge.com:50051')
        self.stub = file_pb2_grpc.DataStreamerStub(self.channel)
        self.user_email = 'yu990524@gmail.com'
        self.competition_code = 'oj' #oj
        self.token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJjb21wZXRpdGlvbl9pZCI6IjYiLCJ1c2VyX2lkIjoieXU5OTA1MjRAZ21haWwuY29tIn0.KP_T1Qt5sDbmN1aZBJ85kqQel10bWWCMDqoCBbupFpE'
        self.predictions_to_send.put(file_pb2.Prediction(rowID=1000, target=333))
        self.metadata = self.create_metadata(user_id=self.user_email, code=self.competition_code, token=self.token)


    def score_for_res(pred, trueval) :
        u2 = (pred-trueval)**2
        v2 = (trueval-trueval.mean())**2
        
        return 1-(u2.sum()/v2.sum())


    def partial_train(mtr, X_test, y_test):
        y_pred, y_std = mtr.predict(X_test, return_std=True)
        mtr.partial_fit(X_test, y_test)
        #print('pred : %f, std: %f, y: %f'%(y_pred, y_std, y_test))
        return y_pred, y_std

    def _init_modeling(self):
        network = pd.read_csv('initial_training_data.csv', index_col='date', parse_dates=['date'])
        network.head()

        rcParams['figure.figsize'] = 17,10

        #construct forest of empty RCTrees
        num_trees = 40
        shingle_size = 60
        tree_size = 256

        self.forest = []
        for _ in range(self.num_trees):
            tree = rrcf.RCTree()
            self.forest.append(tree)


        #train data 정제
        ntw_clean = network.copy()

        train_len = 10000
        ntw_clean = ntw_clean[:train_len]

        #avg_codisp = {}
        self.train_mean = ntw_clean.mean()


        for index in range(0, train_len) :
            point = ntw_clean[index:index+1] #get one by one
        
        for tree in forest :
            if len(tree.leaves) > self.tree_size :
                tree.forget_point(index-self.tree_size)
                
            tree.insert_point(point, index=index)
            
            if not index in avg_codisp :
                self.avg_codisp[index] = 0
            self.avg_codisp[index] += tree.codisp(index) / self.num_trees
        #avg_codisp은 (각 tree 이 point를 anomaly로 생각하는 정도)의 평균
        mean = np.array(list(avg_codisp.values())).mean()
        std = np.array(list(avg_codisp.values())).std()
            
        z = (avg_codisp[index] - mean)/std
        if z > 3.0 or z < -3.0 :
            #if abs(z-score) is over 3.0
            #replace the value with the mean of training data
            
            ntw_clean.iloc[index] = self.train_mean
            
        
        #train set만들기
        tmp = ntw_clean.shift(1)
        tmp2 = ntw_clean.shift(2)
        tmp3 = ntw_clean.shift(3)

        ntw_prev = ntw_clean.copy()
        ntw_prev['prev1'] = tmp['target']
        ntw_prev['prev2'] = tmp2['target']
        ntw_prev['prev3'] = tmp3['target']

        ntw_prev = ntw_prev[4:]
        ntw_prev.tail()

        

        #training은 clean한 data로, test는 clean하지 않은 data를 rrcf로 다시 정제하면서 진행할거임
        #xt = [network[10000:10001], network.iloc[10001], network.iloc[10002]]
        xt = pd.Series()

        mfr = MondrianForestRegressor(random_state = 1, n_estimators=100, bootstrap=True)
        for i in range(3, len(ntw_clean)):
            X_train = pd.Series()
            X_train['prev1'] = ntw_clean[i-3:i-2]['target']
            X_train['prev2'] = ntw_clean[i-2:i-1]['target']
            X_train['prev3'] = ntw_clean[i-1:i]['target']
            y_train = ntw_clean[i:i+1]['target']
            mfr.partial_fit(X_train.values.reshape(1, -1), y_train)

        prediction = np.array([])
        stdeviation = np.array([])

        #일단 Test mean은 train mean과 같게 시작
        test_sum = ntw_clean.sum()
        test_num = ntw_clean.size
        yt = 0

        cleaned = np.array([])
        for i in range(0, 50000) :
            yp = yt
            if (i == 0) : 
                yp = None
            
            yt = network[10004+i:10004+i+1]['target']
            xt['prev1'] = network[10001+i:10001+i+1]['target']
            xt['prev2'] = network[10002+i:10002+i+1]['target']
            xt['prev3'] = network[10003+i:10003+i+1]['target']

            #train의 index가 9999에서 끝났으니까, 10000부터 시작
            index = i+10000
            #yt의 anomaly여부 판단
            for tree in forest :
                if len(tree.leaves) > self.tree_size :
                    tree.forget_point(index-self.tree_size)
                    
                tree.insert_point(yt, index=index)
                
                if not index in avg_codisp :
                    self.avg_codisp[index] = 0
                self.avg_codisp[index] += tree.codisp(index) / self.num_trees
            #avg_codisp은 (각 tree 이 point를 anomaly로 생각하는 정도)의 평균
            mean = np.array(list(avg_codisp.values())).mean()
            std = np.array(list(avg_codisp.values())).std()
                
            z = (self.avg_codisp[index] - mean)/std
            if z > 3.0 or z < -3.0 :
                #if abs(z-score) is over 3.0
                #replace the value with the mean of training data
                print(index, z, yt)
                yt = test_sum/test_num
                print(index, z, yt)
            
        
            cleaned = np.append(cleaned, [yt])
            y_pred, y_std = partial_train(mfr, xt.values.reshape(1, -1), yt)
            #과거 3개만 저장
            np.roll(xt, -1)
            xt[2] = yt
            
            test_sum += yt.values
            test_num += 1
        
            prediction = np.append(prediction, [y_pred])
            stdeviation = np.append(stdeviation, [y_std])

            print("init_training 끝!")
       

    @staticmethod
    def create_metadata(user_id, code, token):
        """
        :param user_id:
        :param code:
        :param token:
        :return:
        """
        metadata = [(b'authorization', bytes(token, 'utf-8')), (b'user_id', bytes(user_id, 'utf-8')),
                    (b'competition_id', bytes(code, 'utf-8'))]
        return metadata

    @staticmethod
    def create_forest(num_trees):

        forest = []
        for _ in range(num_trees):
            tree = rrcf.RCTree()
            forest.append(tree)

        return forest

   

    def generate_predictions(self):
        """
        Sending predictions

        :return: Prediction
        """
        while True:
            try:
                prediction = self.predictions_to_send.get(block=True, timeout=60)
                print("Prediction: ", prediction)
                yield prediction
            except queue.Empty:
                self.stop_thread = True
                break



    #check anomaly with RRCF
    def anomaly_detection(self, data, index):
        for index, point in enumerate(data):  
            for tree in self.forest:
                if len(tree.leaves) > self.tree_size:
                    tree.forget_point(index-self.tree_size)

                tree.insert_point(point, index=index)

                if not index in avg_codisp :
                    self.avg_codisp[index] = 0
                self.avg_codisp[index] += tree.codisp(index)/self.num_trees

        # avg_codisp은 (각 tree 이 point를 anomaly로 생각하는 정도)의 평균
        mean = np.array(list(avg_codisp.values())).mean()
        std = np.array(list(avg_codisp.values())).std()

        z = (self.avg_codisp[index] - mean) / std
        if z > 3.0 or z < -3.0 :
            return self.curr_sum/self.curr_num
            # if abs(z-score) is over 3.0
            # replace the value with the mean of whole data we met

        else :
            return data
        #if not over 3.0, then no need to replace the value



    def loop_messages(self):
        """
        Getting messages (data instances) from the stream.

        :return:
        """

        #generate prediction -> get prediction from predictions_to_send one by one ans SEND to server

        messages = self.stub.sendData(self.generate_predictions(), metadata=self.metadata)
        #print("came here 1")
        #for train, it will iterate 20 times since the initial batch size is 20

        try:
            for message in messages:

                message = json.loads(json_format.MessageToJson(message))
                print("message:", message)
                if message['tag'] == 'TEST':
                    pred = self.mft.predict(self.previous_target_3)
                    prediction = file_pb2_grpc.Prediction(rowId=message['rowID'], target=pred)
                    self.predictions_to_send.put(prediction)

                    target = message['target']
                    target = self.anomaly_detection(target, message['rowID'])
                    self.curr_sum += target

                    # partial fit with 3 previous values as feature
                    self.mfr.partial_fit(self.previous_target_3, target)
                    # replace the latest value with current target value
                    np.roll(self.previous_target_3, -1)
                    self.previous_target_3[2] = target

                if message['tag'] == 'INIT':
                    i = 1
                if message['tag'] == 'TRAIN':
                    #this is training data
                    #if the data features are previous three data, then we need to skip training first three data.
                    #and just save them until we have enough data.

                    target = message['target']
                    target = self.anomaly_detection(target, message['rowID'])
                    self.curr_sum += target

                    if self.previous_target_3.size < 3 :
                        self.previous_target_3 = np.append(self.previous_target_3, [target])
                    else :
                        # partial fit with 3 previous values as feature
                        self.mfr.partial_fit(self.previous_target_3, target)
                        #replace the oldest value with current target value
                        np.roll(self.previous_target_3, -1)
                        self.previous_target_3[2] = target

                if self.stop_thread:
                    break

                self.curr_num += 1



        except Exception as e:
            print(str(e))
            pass

    def run(self):
        """
        Start thread.
        """
        print("Start")
        t1 = Thread(target=self.loop_messages)
        t1.start()


if __name__ == "__main__":
    client_1 = Client(batch_size=5)
    client_1.run()
