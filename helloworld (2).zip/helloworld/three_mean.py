from __future__ import print_function
import grpc
from google.protobuf import json_format
import file_pb2
import file_pb2_grpc
from threading import Thread
import json
from collections.abc import Iterator
import itertools
from json.encoder import JSONEncoder
import ast
from multiprocessing import Queue
import time

from skgarden import MondrianForestRegressor
import numpy as np
import pandas as pd
#import rrcf 

try:
    import queue
except ImportError:
    import Queue as queue


class Client:
    """ gRPC Client class for streaming competition platform"""
    channel = None
    stub = None

    def __init__(self, batch_size):
        '''
        network = pd.read_csv('initial_training_data.csv', index_col='date', parse_dates=['date'])
        data_len=len(network)
        self.arr1=np.array([float(network[network-3:network-2].values),float(network[network-2:network-1].values),float(network[network-1:network].values]))
        self.arr1.append(float(network[network-3:network-2].values))
        arr1.append(float(network[network-3:network-2].values))
        arr1.append(float(network[network-3:network-2].values))
        '''
        """

        :param batch_size: Integer value, defined by the competition and available at competition page
        :param server_port: Connection string ('IP:port')
        :param user_email: String, e-mail used for registering to competition
        :param token: String, received after subscription to a competition
        :param competition_code: String, received after subscription to a competition
        :param first_prediction: Prediction, class generated from .proto file. Used to initiate communication with the
        server. Not influencing the results. Should contain appropriate fields from .proto file.
        """
        self.arr1=np.array([100,90,90])
        self.batch_size = batch_size
        self.stop_thread = False
        self.predictions_to_send = Queue()
        self.channel = grpc.insecure_channel('app.streaming-challenge.com:50051')
        self.stub = file_pb2_grpc.DataStreamerStub(self.channel)
        self.user_email = 'hovy199431@gmail.com'
        self.competition_code = 'jR'
        self.token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoiaG92eTE5OTQzMUBnbWFpbC5jb20iLCJjb21wZXRpdGlvbl9pZCI6MX0.rnGzGEPccxW-4zEOytXTv87FTd_NJxlL78HpDIz_QUQ'
        self.predictions_to_send.put(file_pb2.Prediction(rowID=1000, target=333))
        self.metadata = self.create_metadata(user_id=self.user_email, code=self.competition_code, token=self.token)

        #mondrian
        self.mfr = MondrianForestRegressor(random_state=1, n_estimators=100, bootstrap=True)
        self.previous_target_5 = pd.Series(data=[-1.0, -1.0, -1.0, -1.0, -1.0], index=['prev1', 'prev2', 'prev3', 'prev4', 'prev5'])
        self.features_for_rowID = Queue()
        self.previous_train_batch = np.array([-1, -1, -1, -1, -1])

        
        self.train_idx=0
        self.pre=80
        '''
        #rrcf
        self.num_trees = 40
        self.tree_size = 256
        self.forest = self.create_forest(num_trees=self.num_trees)
        self.avg_codisp = {}
        self.curr_sum = 0
        self.curr_num = 0
        self.previous_sum_5=0 # add previous 5 values
        
        '''
    @staticmethod
    def create_metadata(user_id, code, token):
        """
        :param user_id:
        :param code:
        :param token:
        :return:
        """
        metadata = [(b'authorization', bytes(token, 'utf-8')), (b'user_id', bytes(user_id, 'utf-8')),
                    (b'competition_id', bytes(code, 'utf-8'))]
        return metadata
    '''
    @staticmethod
    def create_forest(num_trees):

        forest = []
        for _ in range(num_trees):
            tree = rrcf.RCTree()
            forest.append(tree)

        return forest
    '''

    def generate_predictions(self):
        """
        Sending predictions

        :return: Prediction
        """
        while True:
            try:
                prediction = self.predictions_to_send.get(block=True, timeout=60)
                print("Prediction: ", prediction)
                yield prediction
            except queue.Empty:
                self.stop_thread = True
                break

    
    # predict with previous 5 values' mean
    def predict_mean(self, previous_target_5):
        self.previous_sum_5 = previous_target_5['prev5']
        self.previous_sum_5 += previous_target_5['prev4']
        self.previous_sum_5 += previous_target_5['prev3']
        self.previous_sum_5 += previous_target_5['prev2']
        self.previous_sum_5 += previous_target_5['prev1']
        # add all the previous 5 values
        
        return previous_target_5 / 5 # and return the mean

    def func(self,val):
        self.arr1[0]=self.arr1[1]
        self.arr1[1]=self.arr1[2]
        self.arr1[2]=val
        #self.arr1[3]=self.arr1[4]
        #self.arr1[4]=val

        self.pre=self.arr1.mean()
    


    def loop_messages(self):
        """
        Getting messages (data instances) from the stream.

        :return:
        """

        #generate prediction -> get prediction from predictions_to_send one by one ans SEND to server

        messages = self.stub.sendData(self.generate_predictions(), metadata=self.metadata)
        test_idx = 0
        test_feature = self.previous_target_5

        try:
            for message in messages:

                message = json.loads(json_format.MessageToJson(message))
                print("message:", message)

                if message['tag'] == 'TEST':
                    self.func(self.pre)
                    prediction = file_pb2.Prediction(rowID=message['rowID'], target=self.pre)
                    self.predictions_to_send.put(prediction)

                if message['tag'] == 'TRAIN':
                    #training data to train my model.
                    target = message['target']
                    #print("target: ",target)
                    self.func(target)
                    
                if message['tag'] == 'INIT':
                    i = 1
                if self.stop_thread : break


        except Exception as e:
            print(str(e))
            pass

    def run(self):
        """
        Start thread.
        """
        print("Start")
        t1 = Thread(target=self.loop_messages)
        t1.start()


if __name__ == "__main__":
    client_1 = Client(batch_size=5)
    client_1.run()